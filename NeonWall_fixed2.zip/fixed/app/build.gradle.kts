plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.neonwall.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.neonwall.app"
        minSdk = 29          // BlendMode.PLUS, thermal API, Visualizer, lockHardwareCanvas
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Shaxsiy sinov uchun debug kalit bilan imzolanadi. Nashr qilishda o'zingizning keystore'ingizni qo'ying.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    // Compose (UI + Glassmorphism + RenderEffect orqali Modifier.blur)
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Vidjetlar (Glance = AppWidgetProvider ustidagi Compose-uslubidagi framework)
    implementation("androidx.glance:glance-appwidget:1.1.1")

    // Fon yangilanishlari (ob-havo + vidjetlar)
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
