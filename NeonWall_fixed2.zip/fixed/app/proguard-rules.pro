# Glance actionRunCallback<T>() klassni NOMI bilan saqlaydi va reflection orqali yaratadi.
# R8 nomini o'zgartirsa yoki o'chirsa, tugma bosilganda ishlamaydi.
-keep class * implements androidx.glance.appwidget.action.ActionCallback { <init>(); }
# WorkManager Worker'lari uchun consumer-rules mavjud, lekin aniqlik uchun:
-keep class * extends androidx.work.ListenableWorker { <init>(android.content.Context, androidx.work.WorkerParameters); }
