package com.neonwall.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.neonwall.app.data.SettingsRepository
import com.neonwall.app.data.WallpaperSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)

    val settings: StateFlow<WallpaperSettings> =
        repo.observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), repo.load())

    fun update(transform: (WallpaperSettings) -> WallpaperSettings) = repo.update(transform)
}
