package com.neonwall.app.widget

import android.content.Context
import android.media.AudioManager
import android.os.SystemClock
import android.view.KeyEvent
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ContentScale
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.neonwall.app.MainActivity
import com.neonwall.app.R
import com.neonwall.app.data.NowPlaying
import com.neonwall.app.data.NowPlayingStore
import com.neonwall.app.ui.theme.Neon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Hozir chalinayotgan qo'shiq + cover art + boshqaruv tugmalari. */
class MusicWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val nowPlaying = withContext(Dispatchers.IO) { NowPlayingStore(context).load() }
        provideContent { MusicContent(nowPlaying) }
    }
}

@Composable
private fun MusicContent(np: NowPlaying?) {
    Row(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.bg_widget_glass))
            .padding(12.dp)
            .clickable(actionStartActivity<MainActivity>()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val cover = np?.cover
        if (cover != null) {
            Image(
                provider = ImageProvider(cover),
                contentDescription = "Album cover",
                contentScale = ContentScale.Crop,
                modifier = GlanceModifier.size(84.dp).cornerRadius(16.dp),
            )
        } else {
            Text("♪", style = TextStyle(color = ColorProvider(Neon.Magenta), fontSize = 44.sp))
        }
        Spacer(GlanceModifier.width(12.dp))
        Column(modifier = GlanceModifier.defaultWeight()) {
            Text(
                text = np?.title ?: "Nothing playing",
                maxLines = 1,
                style = TextStyle(color = ColorProvider(Neon.TextPrimary), fontSize = 15.sp, fontWeight = FontWeight.Bold),
            )
            Text(
                text = np?.artist ?: "Notification access kerak (ilovada yoqing)",
                maxLines = 1,
                style = TextStyle(color = ColorProvider(Neon.TextDim), fontSize = 12.sp),
            )
            Spacer(GlanceModifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                MediaButton("⏮", KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                MediaButton(if (np?.isPlaying == true) "⏸" else "▶", KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, Neon.Cyan)
                MediaButton("⏭", KeyEvent.KEYCODE_MEDIA_NEXT)
            }
        }
    }
}

@Composable
private fun MediaButton(glyph: String, keyCode: Int, color: androidx.compose.ui.graphics.Color = Neon.Magenta) {
    Text(
        text = glyph,
        style = TextStyle(color = ColorProvider(color), fontSize = 26.sp),
        modifier = GlanceModifier
            .padding(end = 14.dp)
            .clickable(actionRunCallback<MediaKeyCallback>(actionParametersOf(MediaKeyCallback.KEY to keyCode))),
    )
}

/** Media tugmasi hodisasini yuboradi — qaysi pleyer faol bo'lsa, o'sha javob beradi (ruxsat shart emas). */
class MediaKeyCallback : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val keyCode = parameters[KEY] ?: return
        val audio = context.getSystemService(AudioManager::class.java)
        // eventTime/downTime berilmasa ba'zi pleyerlar hodisani e'tiborsiz qoldiradi
        val now = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
    }

    companion object {
        val KEY = ActionParameters.Key<Int>("media_key")
    }
}

class MusicWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = MusicWidget()
}
