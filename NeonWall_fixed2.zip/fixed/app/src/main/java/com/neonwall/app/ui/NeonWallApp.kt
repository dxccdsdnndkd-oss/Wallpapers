package com.neonwall.app.ui

import android.Manifest
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.neonwall.app.data.AccentMode
import com.neonwall.app.data.BatteryReader
import com.neonwall.app.data.WallpaperSettings
import com.neonwall.app.power.DisplayInfo
import com.neonwall.app.power.PowerPolicyEvaluator
import com.neonwall.app.power.RenderPolicy
import com.neonwall.app.ui.components.GlassCard
import com.neonwall.app.ui.components.GlassNavBar
import com.neonwall.app.ui.components.LivePreview
import com.neonwall.app.ui.components.NeonBackground
import com.neonwall.app.ui.components.NeonButton
import com.neonwall.app.ui.components.ScreenColumn
import com.neonwall.app.ui.components.ScreenHeader
import com.neonwall.app.ui.components.SectionTitle
import com.neonwall.app.ui.components.SliderRow
import com.neonwall.app.ui.components.SwitchRow
import com.neonwall.app.ui.theme.Neon
import com.neonwall.app.wallpaper.NeonWallpaperService
import com.neonwall.app.widget.ClockWeatherWidgetReceiver
import com.neonwall.app.widget.MusicWidgetReceiver
import com.neonwall.app.widget.RefreshWorker
import com.neonwall.app.widget.SystemMonitorWidgetReceiver
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private typealias SettingsUpdate = ((WallpaperSettings) -> WallpaperSettings) -> Unit

@Composable
fun NeonWallApp(vm: MainViewModel = viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    NeonBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = { GlassNavBar(tab) { tab = it } },
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (tab) {
                    0 -> WallpaperScreen(settings, vm::update)
                    1 -> WidgetsScreen()
                    else -> PowerScreen(settings, vm::update)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Wallpaper

@Composable
private fun WallpaperScreen(settings: WallpaperSettings, onChange: SettingsUpdate) {
    val ctx = LocalContext.current
    var audioGranted by remember { mutableStateOf(ctx.has(Manifest.permission.RECORD_AUDIO)) }
    var locationGranted by remember { mutableStateOf(ctx.has(Manifest.permission.ACCESS_COARSE_LOCATION)) }
    val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioGranted = it }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        locationGranted = it
        if (it) RefreshWorker.runNow(ctx)
    }

    ScreenColumn {
        ScreenHeader("NEON//WALL", "Interactive live wallpaper")

        GlassCard {
            LivePreview(Modifier.fillMaxWidth().height(200.dp))
            Spacer(Modifier.height(16.dp))
            NeonButton("SET AS LIVE WALLPAPER") { launchWallpaperPicker(ctx) }
        }

        GlassCard(accent = Neon.Magenta) {
            SectionTitle("Interaction", Neon.Magenta)
            SwitchRow("Gyro parallax", "Telefonni qiyshaytirganda fon siljiydi", settings.parallaxEnabled) { v -> onChange { it.copy(parallaxEnabled = v) } }
            SwitchRow("Touch reaction", "Teginganda to'lqin va zarrachalar", settings.touchEnabled) { v -> onChange { it.copy(touchEnabled = v) } }
            SwitchRow("Audio visualizer", "Musiqaga javob beruvchi spektr", settings.audioEnabled) { v -> onChange { it.copy(audioEnabled = v) } }
            SwitchRow("Day / Night + weather", "Vaqt va ob-havoga qarab ranglar", settings.dayNightEnabled) { v -> onChange { it.copy(dayNightEnabled = v) } }
        }

        GlassCard {
            SectionTitle("Look & feel")
            SliderRow("Parallax strength", "${(settings.parallaxStrength * 100).roundToInt()}%", settings.parallaxStrength, 0f..1f) { v -> onChange { it.copy(parallaxStrength = v) } }
            SliderRow("Particle density", "${(settings.particleDensity * 100).roundToInt()}%", settings.particleDensity, 0f..1f) { v -> onChange { it.copy(particleDensity = v) } }
            Text("Accent", color = Neon.TextPrimary, modifier = Modifier.padding(top = 8.dp))
            ChipRow(AccentMode.entries.toList(), settings.accent, { it.label }) { a -> onChange { it.copy(accent = a) } }
            Text("Max FPS (ekran: ${DisplayInfo.maxRefreshHz(ctx)} Hz)", color = Neon.TextPrimary, modifier = Modifier.padding(top = 12.dp))
            ChipRow(listOf(30, 60, 90, 120, 144), settings.maxFps, { "$it" }) { f -> onChange { it.copy(maxFps = f) } }
        }

        GlassCard(accent = Neon.Lime) {
            SectionTitle("Permissions", Neon.Lime)
            PermissionRow("Microphone (audio visualizer)", audioGranted) { audioLauncher.launch(Manifest.permission.RECORD_AUDIO) }
            PermissionRow("Approx. location (weather)", locationGranted) { locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION) }
        }
    }
}

// ---------------------------------------------------------------- Widgets

@Composable
private fun WidgetsScreen() {
    val ctx = LocalContext.current
    var listenerEnabled by remember { mutableStateOf(isListenerEnabled(ctx)) }
    LaunchedEffect(Unit) { while (true) { listenerEnabled = isListenerEnabled(ctx); delay(2_000) } }

    ScreenColumn {
        ScreenHeader("WIDGETS", "Neon glass widget collection")
        WidgetCard("Digital Clock & Weather", "Neon soat, sana, harorat va ob-havo holati.") { pinWidget(ctx, ClockWeatherWidgetReceiver::class.java) }
        WidgetCard("System Monitor", "CPU, RAM, batareya va harorat. Uy ekrani ko'ringanda yangilanadi.") { pinWidget(ctx, SystemMonitorWidgetReceiver::class.java) }
        WidgetCard("Music Player", "Hozir chalinayotgan qo'shiq, cover art va boshqaruv tugmalari.") { pinWidget(ctx, MusicWidgetReceiver::class.java) }
        GlassCard(accent = Neon.Amber) {
            SectionTitle("Music access", Neon.Amber)
            Text(
                if (listenerEnabled) "Notification access yoqilgan ✓" else "Musiqa ma'lumotini o'qish uchun Notification access yoqing.",
                color = Neon.TextDim, fontSize = 13.sp,
            )
            if (!listenerEnabled) {
                Spacer(Modifier.height(12.dp))
                NeonButton("OPEN SETTINGS") { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            }
        }
    }
}

@Composable
private fun WidgetCard(title: String, description: String, onAdd: () -> Unit) {
    GlassCard {
        Text(title, color = Neon.TextPrimary, fontSize = 17.sp)
        Text(description, color = Neon.TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        NeonButton("ADD TO HOME SCREEN", onClick = onAdd)
    }
}

// ---------------------------------------------------------------- Power

@Composable
private fun PowerScreen(settings: WallpaperSettings, onChange: SettingsUpdate) {
    val ctx = LocalContext.current
    var policy by remember { mutableStateOf<RenderPolicy?>(null) }
    var battery by remember { mutableStateOf(BatteryReader.read(ctx)) }
    LaunchedEffect(settings) {
        val evaluator = PowerPolicyEvaluator(ctx)
        val hz = DisplayInfo.maxRefreshHz(ctx)
        while (true) {
            battery = BatteryReader.read(ctx)
            policy = evaluator.evaluate(settings, hz)
            delay(3_000)
        }
    }

    ScreenColumn {
        ScreenHeader("POWER", "Battery saver control")
        GlassCard(accent = Neon.Lime) {
            SectionTitle("Live status", Neon.Lime)
            Text("${battery.percent}%" + if (battery.charging) "  ⚡ charging" else "", color = Neon.TextPrimary, fontSize = 32.sp)
            Text("%.1f°C".format(battery.tempC), color = Neon.TextDim)
            Spacer(Modifier.height(8.dp))
            Text(policy?.reason ?: "…", color = Neon.Cyan)
        }
        GlassCard {
            SectionTitle("Rules")
            SliderRow("Low battery threshold", "${settings.batteryThreshold}%", settings.batteryThreshold.toFloat(), 10f..50f, steps = 7) { v ->
                onChange { it.copy(batteryThreshold = v.roundToInt()) }
            }
            Text("Shundan pastda 30 FPS va kamroq zarrachalar. 10% dan pastda animatsiya to'xtaydi.", color = Neon.TextDim, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            SwitchRow("Game mode", "Animatsiyani to'liq to'xtatadi (o'yin vaqtida yoqing)", settings.gameMode) { v -> onChange { it.copy(gameMode = v) } }
        }
    }
}

// ---------------------------------------------------------------- helpers

@Composable
private fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Neon.Cyan.copy(0.2f), selectedLabelColor = Neon.Cyan,
                    labelColor = Neon.TextDim,
                ),
            )
        }
    }
}

@Composable
private fun PermissionRow(title: String, granted: Boolean, onRequest: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(title, color = Neon.TextPrimary, modifier = Modifier.weight(1f))
        if (granted) Text("✓", color = Neon.Lime, fontSize = 20.sp)
        else Text("GRANT", color = Neon.Cyan, modifier = Modifier.padding(8.dp).clickable(onClick = onRequest))
    }
}


private fun Context.has(permission: String) =
    ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

private fun isListenerEnabled(ctx: Context) =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

private fun launchWallpaperPicker(ctx: Context) {
    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
        ComponentName(ctx, NeonWallpaperService::class.java),
    )
    runCatching { ctx.startActivity(intent) }
        .onFailure { ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
}

private fun pinWidget(ctx: Context, receiver: Class<*>) {
    val manager = AppWidgetManager.getInstance(ctx)
    if (manager.isRequestPinAppWidgetSupported) {
        manager.requestPinAppWidget(ComponentName(ctx, receiver), null, null)
    } else {
        Toast.makeText(ctx, "Launcher qo'llab-quvvatlamaydi: vidjetni qo'lda qo'shing", Toast.LENGTH_LONG).show()
    }
}
