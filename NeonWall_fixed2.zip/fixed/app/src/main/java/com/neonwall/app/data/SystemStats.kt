package com.neonwall.app.data

import android.app.ActivityManager
import android.content.Context
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.roundToInt

data class SystemSnapshot(
    val cpuPercent: Int?,          // null = qurilma o'qishga ruxsat bermadi
    val ramPercent: Int,
    val ramUsedGb: Float,
    val ramTotalGb: Float,
    val batteryPercent: Int,
    val batteryTempC: Float,
    val charging: Boolean,
)

/**
 * Tizim ko'rsatkichlari.
 * DIQQAT: Android 8+ da oddiy ilovalar uchun /proc/stat ko'pincha yopiq. Shuning uchun:
 *   1) /proc/stat (agar o'qilsa — haqiqiy yuklama),
 *   2) cpufreq (joriy/maksimal chastota nisbati — yuklamaning taxminiy ko'rsatkichi),
 *   3) ikkalasi ham bo'lmasa null ("—").
 */
class SystemStatsReader(context: Context) {
    private val context = context.applicationContext

    suspend fun read(): SystemSnapshot {
        val mem = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java).getMemoryInfo(mem)
        val total = mem.totalMem.toFloat()
        val used = total - mem.availMem
        val battery = BatteryReader.read(context)
        return SystemSnapshot(
            cpuPercent = cpuFromProcStat() ?: cpuFromFrequency(),
            ramPercent = (used / total * 100f).roundToInt().coerceIn(0, 100),
            ramUsedGb = used / GB,
            ramTotalGb = total / GB,
            batteryPercent = battery.percent,
            batteryTempC = battery.tempC,
            charging = battery.charging,
        )
    }

    private suspend fun cpuFromProcStat(): Int? {
        val first = readProcStat() ?: return null
        delay(250)
        val second = readProcStat() ?: return null
        val total = second.first - first.first
        val idle = second.second - first.second
        return if (total > 0) (((total - idle) * 100f) / total).roundToInt().coerceIn(0, 100) else null
    }

    /** Returns (totalJiffies, idleJiffies) */
    private fun readProcStat(): Pair<Long, Long>? = runCatching {
        val line = File("/proc/stat").bufferedReader().use { it.readLine() }
        val p = line.trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
        p.sum() to (p[3] + p[4])
    }.getOrNull()

    private fun cpuFromFrequency(): Int? {
        val cores = File("/sys/devices/system/cpu").listFiles { f -> f.name.matches(Regex("cpu\\d+")) }
            ?: return null
        var cur = 0L
        var max = 0L
        for (core in cores) {
            val c = runCatching { File(core, "cpufreq/scaling_cur_freq").readText().trim().toLong() }.getOrNull()
            val m = runCatching { File(core, "cpufreq/cpuinfo_max_freq").readText().trim().toLong() }.getOrNull()
            if (c != null && m != null) { cur += c; max += m }
        }
        return if (max > 0) ((cur * 100f) / max).roundToInt().coerceIn(0, 100) else null
    }

    private companion object { const val GB = 1024f * 1024f * 1024f }
}
