package com.neonwall.app.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.LinearProgressIndicator
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.neonwall.app.MainActivity
import com.neonwall.app.R
import com.neonwall.app.data.SystemSnapshot
import com.neonwall.app.data.SystemStatsReader
import com.neonwall.app.ui.theme.Neon
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** CPU / RAM / Battery + harorat. Minimalist progress-barlar. */
class SystemMonitorWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val snapshot = withContext(Dispatchers.IO) { SystemStatsReader(context).read() }
        provideContent { SystemMonitorContent(snapshot) }
    }
}

@Composable
private fun SystemMonitorContent(s: SystemSnapshot) {
    val batteryColor = when {
        s.batteryPercent <= 15 -> Color(0xFFFF1744)
        s.batteryPercent <= 30 -> Neon.Amber
        else -> Neon.Lime
    }
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.bg_widget_glass))
            .padding(16.dp)
            .clickable(actionStartActivity(android.content.Intent(androidx.glance.LocalContext.current, MainActivity::class.java))),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "SYS // MONITOR",
            style = TextStyle(color = ColorProvider(Neon.Cyan), fontSize = 11.sp, fontWeight = FontWeight.Bold),
        )
        Spacer(GlanceModifier.height(8.dp))
        MetricRow("CPU", s.cpuPercent?.let { "$it%" } ?: "—", (s.cpuPercent ?: 0) / 100f, Neon.Cyan)
        MetricRow("RAM", "${s.ramPercent}%", s.ramPercent / 100f, Neon.Magenta)
        MetricRow(
            "BAT",
            "${s.batteryPercent}%" + if (s.charging) " ⚡" else "",
            s.batteryPercent / 100f,
            batteryColor,
        )
        Text(
            text = String.format(
                Locale.US, "%.1f°C  ·  %.1f / %.1f GB", s.batteryTempC, s.ramUsedGb, s.ramTotalGb,
            ),
            style = TextStyle(color = ColorProvider(Neon.TextDim), fontSize = 11.sp),
        )
    }
}

@Composable
private fun MetricRow(label: String, value: String, progress: Float, color: Color) {
    Column(modifier = GlanceModifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Row(modifier = GlanceModifier.fillMaxWidth()) {
            Text(
                text = label,
                modifier = GlanceModifier.defaultWeight(),
                style = TextStyle(color = ColorProvider(Neon.TextPrimary), fontSize = 12.sp, fontWeight = FontWeight.Medium),
            )
            Text(
                text = value,
                style = TextStyle(color = ColorProvider(color), fontSize = 12.sp, fontWeight = FontWeight.Bold),
            )
        }
        Spacer(GlanceModifier.height(3.dp))
        LinearProgressIndicator(
            progress = progress.coerceIn(0f, 1f),
            modifier = GlanceModifier.fillMaxWidth().height(4.dp),
            color = ColorProvider(color),
            backgroundColor = ColorProvider(Color(0x33FFFFFF)),
        )
    }
}

class SystemMonitorWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = SystemMonitorWidget()
}
