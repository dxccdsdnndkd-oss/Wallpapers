package com.neonwall.app.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

data class BatteryInfo(val percent: Int, val tempC: Float, val charging: Boolean)

object BatteryReader {
    /** Sticky broadcast: receiver ro'yxatdan o'tkazmasdan joriy holatni sinxron o'qiydi. */
    fun read(context: Context): BatteryInfo {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0   // 0.1°C birlikda
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return BatteryInfo(
            percent = if (level < 0) 100 else level * 100 / scale,
            tempC = temp / 10f,
            charging = charging,
        )
    }
}
