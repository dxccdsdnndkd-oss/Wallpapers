package com.neonwall.app.data

enum class WeatherCondition(val label: String, val glyph: String) {
    CLEAR("Clear", "☀"),
    CLOUDY("Cloudy", "☁"),
    FOG("Fog", "≋"),
    RAIN("Rain", "☂"),
    SNOW("Snow", "❄"),
    STORM("Storm", "⚡");

    companion object {
        /** WMO weather code (Open-Meteo) → bizning yengil enum. */
        fun fromWmo(code: Int): WeatherCondition = when (code) {
            0, 1 -> CLEAR
            2, 3 -> CLOUDY
            45, 48 -> FOG
            in 51..67, in 80..82 -> RAIN
            in 71..77, 85, 86 -> SNOW
            in 95..99 -> STORM
            else -> CLOUDY
        }
    }
}

data class WeatherSnapshot(
    val tempC: Float,
    val condition: WeatherCondition,
    val isDay: Boolean,
    val updatedAt: Long,
    /** Bugungi quyosh chiqishi/botishi, epoch ms (null = qutb kechasi/kunduzi yoki ma'lumot yo'q). */
    val sunriseMs: Long? = null,
    val sunsetMs: Long? = null,
)
