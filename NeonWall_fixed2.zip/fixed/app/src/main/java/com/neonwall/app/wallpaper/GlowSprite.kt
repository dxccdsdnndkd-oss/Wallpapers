package com.neonwall.app.wallpaper

import android.graphics.Bitmap
import android.graphics.BlendMode
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader

/**
 * Oldindan chizilgan oq radial "nur" bitmap'i. Hardware canvas'da BlurMaskFilter ishonchsiz,
 * shuning uchun neon glow = bitta sprite'ni rangga bo'yab, additive (PLUS) aralashtirish bilan chizamiz.
 * Bu har kadrda yuzlab glow'ni deyarli bepul chizish imkonini beradi.
 */
class GlowSprite(sizePx: Int = 96) {
    private val bitmap: Bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).also { bmp ->
        val r = sizePx / 2f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                r, r, r,
                intArrayOf(Color.WHITE, 0x66FFFFFF, Color.TRANSPARENT),
                floatArrayOf(0f, 0.25f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        Canvas(bmp).drawCircle(r, r, r, paint)
    }
    private val src = Rect(0, 0, sizePx, sizePx)
    private val dst = RectF()

    fun draw(canvas: Canvas, cx: Float, cy: Float, radius: Float, paint: Paint) {
        dst.set(cx - radius, cy - radius, cx + radius, cy + radius)
        canvas.drawBitmap(bitmap, src, dst, paint)
    }
}

/** Glow rangi uchun Paint; ColorFilter faqat rang o'zgargandagina qayta yaratiladi. */
class TintedPaint {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { blendMode = BlendMode.PLUS }
    private var color = 0

    fun tint(c: Int) {
        if (c != color) {
            color = c
            paint.colorFilter = PorterDuffColorFilter(c, PorterDuff.Mode.SRC_IN)
        }
    }
}
