package com.neonwall.app.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/** Cyberpunk palitrasi. Vidjetlar (Glance) ham shu ranglardan foydalanadi. */
object Neon {
    val Cyan = Color(0xFF00E5FF)
    val Magenta = Color(0xFFFF2BD6)
    val Lime = Color(0xFF76FF03)
    val Amber = Color(0xFFFFAB00)
    val Void = Color(0xFF000000)          // AMOLED: sof qora piksellar o'chiq turadi
    val Surface = Color(0xFF0A0F1A)
    val TextPrimary = Color(0xFFE8F6FF)
    val TextDim = Color(0xFF8CA3B8)
}

/**
 * Material You: Android 12+ da ikkilamchi rang tizim (devor) rangidan olinadi,
 * qolgan hammasi neon-AMOLED uslubida qat'iy.
 */
@Composable
fun NeonWallTheme(content: @Composable () -> Unit) {
    val dynamic = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) dynamicDarkColorScheme(LocalContext.current) else null
    val scheme = darkColorScheme(
        primary = Neon.Cyan,
        onPrimary = Color.Black,
        secondary = dynamic?.primary ?: Neon.Magenta,
        tertiary = Neon.Lime,
        background = Neon.Void,
        surface = Neon.Surface,
        onBackground = Neon.TextPrimary,
        onSurface = Neon.TextPrimary,
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
