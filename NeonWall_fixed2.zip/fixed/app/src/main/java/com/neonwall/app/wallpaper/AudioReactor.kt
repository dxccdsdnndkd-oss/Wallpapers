package com.neonwall.app.wallpaper

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.audiofx.Visualizer
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Musiqaga reaksiya. Birinchi navbatda Visualizer (global mix, session 0) FFT'si ishlatiladi.
 * Ba'zi qurilmalar/ilovalar (DRM, Android 13+ cheklovlari) nol qaytaradi — u holda
 * `AudioManager.isMusicActive` true bo'lganda sintetik "puls" animatsiyasi ko'rsatiladi.
 */
class AudioReactor(context: Context) {
    private val context = context.applicationContext
    private val audioManager = this.context.getSystemService(AudioManager::class.java)

    val levels = FloatArray(BAR_COUNT)
    var energy = 0f
        private set

    private val target = FloatArray(BAR_COUNT)
    private var fft = ByteArray(FFT_SIZE)
    private var visualizer: Visualizer? = null
    private var active = false
    private var musicActive = false
    private var lastMusicCheck = -1f
    private var lastInitAttemptMs = 0L

    fun start() {
        active = true
        if (visualizer != null) return
        // Ruxsat keyin berilgan bo'lishi mumkin: har ~30 s da qayta urinamiz (o'chiq turgan qurilmada arzon).
        val now = SystemClock.elapsedRealtime()
        if (lastInitAttemptMs != 0L && now - lastInitAttemptMs < RETRY_INTERVAL_MS) return
        lastInitAttemptMs = now
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) visualizer = createVisualizer()
    }

    /** Sessiya 0 = global mix. Istisno bo'lsa, yarim-yaratilgan Visualizer'ni albatta release qiladi (oqish yo'q). */
    private fun createVisualizer(): Visualizer? {
        var v: Visualizer? = null
        return try {
            v = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()                 // odatda [128, 1024]
            val size = FFT_SIZE.coerceIn(range[0], range[1])
            v.setCaptureSize(size)                                       // faqat enabled=false holatda ruxsat
            fft = ByteArray(size)                                        // getFft buferi captureSize'ga teng bo'lsin
            v.setEnabled(true)
            v
        } catch (t: Throwable) {
            runCatching { v?.release() }
            null
        }
    }

    fun stop() {
        if (!active) return
        active = false
        runCatching { visualizer?.setEnabled(false); visualizer?.release() }
        visualizer = null
        levels.fill(0f)
        energy = 0f
    }

    fun update(time: Float, dt: Float) {
        // stop() qilingan bo'lsa (sozlama o'chiq / past quvvat) sintetik puls ham ishlamasin
        if (!active) return
        // isMusicActive — IPC chaqiruv; sekundiga ~2 marta yetarli.
        // DIQQAT: `time` soatiga bir marta 0 ga o'raladi (NeonWallpaperService.TIME_WRAP_SEC). `time < lastMusicCheck`
        // sharti bo'lmasa, o'ralgandan keyin ayirma manfiy bo'lib qolardi va musiqa holati abadiy yangilanmasdi.
        if (lastMusicCheck < 0f || time < lastMusicCheck || time - lastMusicCheck > 0.5f) {
            musicActive = audioManager.isMusicActive
            lastMusicCheck = time
        }
        when {
            !musicActive -> target.fill(0f)
            readFft() -> Unit
            else -> synthesize(time)
        }
        val up = 1f - exp(-dt * 25f)
        val down = 1f - exp(-dt * 6f)
        var bass = 0f
        for (i in 0 until BAR_COUNT) {
            levels[i] += (target[i] - levels[i]) * (if (target[i] > levels[i]) up else down)
            if (i < BASS_BARS) bass += levels[i]
        }
        energy = bass / BASS_BARS
    }

    /** FFT -> logaritmik taqsimlangan BAR_COUNT ta chiziq. true = haqiqiy signal bor. */
    private fun readFft(): Boolean {
        val vis = visualizer ?: return false
        if (vis.getFft(fft) != Visualizer.SUCCESS) return false
        val bins = fft.size / 2
        var total = 0f
        for (b in 0 until BAR_COUNT) {
            val from = 1 + (bins * 0.5f * (b / BAR_COUNT.toFloat()).pow(2f)).toInt()
            val to = max(from + 1, 1 + (bins * 0.5f * ((b + 1) / BAR_COUNT.toFloat()).pow(2f)).toInt())
            var sum = 0f
            for (k in from until min(to, bins)) {
                sum += hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat())
            }
            val v = ((sum / (to - from)) / 90f).coerceIn(0f, 1f)
            target[b] = v
            total += v
        }
        return total > 0.5f
    }

    private fun synthesize(time: Float) {
        val beat = 0.55f + 0.45f * abs(sin(time * 4.2f))
        for (i in 0 until BAR_COUNT) {
            val falloff = 1f - i / (BAR_COUNT * 1.4f)
            target[i] = (abs(sin(time * (1.7f + i * 0.21f) + i)) * 0.7f * beat * falloff).coerceIn(0f, 1f)
        }
    }

    companion object {
        const val BAR_COUNT = 40
        private const val FFT_SIZE = 512
        private const val BASS_BARS = 5
        private const val RETRY_INTERVAL_MS = 30_000L
    }
}
