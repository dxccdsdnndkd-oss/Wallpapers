package com.neonwall.app.power

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.PowerManager
import android.view.Display
import com.neonwall.app.data.BatteryReader
import com.neonwall.app.data.WallpaperSettings
import kotlin.math.min
import kotlin.math.roundToInt

/** Render qarori: nechta FPS, animatsiya yoqilganmi, zarrachalar zichligi koeffitsienti. */
data class RenderPolicy(
    val targetFps: Int,
    val animate: Boolean,
    val densityScale: Float,
    val reason: String,
)

object DisplayInfo {
    /** Ekran qo'llab-quvvatlaydigan eng yuqori yangilanish chastotasi (Poco: 120/144 Hz). */
    fun maxRefreshHz(context: Context): Int {
        val display = context.getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY) ?: return 60
        return display.supportedModes.maxOfOrNull { it.refreshRate }?.roundToInt() ?: 60
    }
}

/**
 * Battery Saver Control:
 *  - O'yin rejimi            -> animatsiya TO'XTAYDI (statik kadr)
 *  - Batareya <= 10% (zaryadsiz) -> animatsiya TO'XTAYDI
 *  - Batareya <= sozlama (20%) / Power Saver / qizish -> 30 FPS, zarrachalar kamayadi
 *  - Aks holda               -> min(foydalanuvchi limiti, ekran maksimumi) FPS
 */
class PowerPolicyEvaluator(context: Context) {
    private val context = context.applicationContext
    private val powerManager = this.context.getSystemService(PowerManager::class.java)

    fun evaluate(settings: WallpaperSettings, displayMaxHz: Int): RenderPolicy {
        val fullFps = min(settings.maxFps, displayMaxHz)
        val battery = BatteryReader.read(context)
        val critical = !battery.charging && battery.percent <= CRITICAL_PERCENT
        val low = !battery.charging && battery.percent <= settings.batteryThreshold
        val hot = powerManager.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE

        return when {
            settings.gameMode -> RenderPolicy(0, false, 0f, "Game mode: animation paused")
            critical -> RenderPolicy(0, false, 0f, "Battery critical: animation paused")
            hot -> RenderPolicy(30, true, 0.4f, "Device hot: 30 FPS")
            low -> RenderPolicy(30, true, 0.5f, "Battery low: 30 FPS")
            powerManager.isPowerSaveMode -> RenderPolicy(30, true, 0.5f, "Power Saver: 30 FPS")
            else -> RenderPolicy(fullFps, true, 1f, "Performance: $fullFps FPS")
        }
    }

    private companion object { const val CRITICAL_PERCENT = 10 }
}
