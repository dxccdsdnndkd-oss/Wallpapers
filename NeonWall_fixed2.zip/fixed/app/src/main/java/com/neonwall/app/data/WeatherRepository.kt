package com.neonwall.app.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.net.HttpURLConnection
import java.net.URL

/**
 * Open-Meteo (API kalit talab qilmaydi) orqali ob-havo oladi va keshlaydi.
 * Joylashuv: ACCESS_COARSE_LOCATION berilgan bo'lsa — oxirgi ma'lum joy, aks holda Toshkent.
 */
class WeatherRepository(context: Context) {

    private val context = context.applicationContext
    private val prefs = this.context.getSharedPreferences("neonwall_weather", Context.MODE_PRIVATE)

    fun cached(): WeatherSnapshot? {
        if (!prefs.contains(K_UPDATED)) return null
        return WeatherSnapshot(
            tempC = prefs.getFloat(K_TEMP, 0f),
            condition = runCatching { WeatherCondition.valueOf(prefs.getString(K_COND, null) ?: "") }
                .getOrDefault(WeatherCondition.CLEAR),
            isDay = prefs.getBoolean(K_DAY, true),
            updatedAt = prefs.getLong(K_UPDATED, 0L),
            sunriseMs = prefs.getLong(K_SUNRISE, 0L).takeIf { it > 0L },
            sunsetMs = prefs.getLong(K_SUNSET, 0L).takeIf { it > 0L },
        )
    }

    suspend fun refresh(): WeatherSnapshot? = withContext(Dispatchers.IO) {
        runCatching {
            val (lat, lon) = lastKnownLocation()
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code,is_day&daily=sunrise,sunset&forecast_days=1&timezone=auto"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 8_000
            }
            try {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(body)
                val cur = root.getJSONObject("current")
                // timezone=auto bo'lganda vaqtlar JOYLASHUV mahalliy vaqtida ("2026-10-28T06:35");
                // utc_offset_seconds yordamida mutlaq epoch'ga aylantiramiz.
                val offset = root.optInt("utc_offset_seconds", 0)
                val daily = root.optJSONObject("daily")
                WeatherSnapshot(
                    tempC = cur.getDouble("temperature_2m").toFloat(),
                    condition = WeatherCondition.fromWmo(cur.getInt("weather_code")),
                    isDay = cur.getInt("is_day") == 1,
                    updatedAt = System.currentTimeMillis(),
                    sunriseMs = parseLocalTime(daily?.optJSONArray("sunrise")?.optString(0), offset),
                    sunsetMs = parseLocalTime(daily?.optJSONArray("sunset")?.optString(0), offset),
                ).also { store(it) }
            } finally {
                conn.disconnect()
            }
        }.getOrNull()
    }

    private fun store(s: WeatherSnapshot) {
        prefs.edit()
            .putFloat(K_TEMP, s.tempC)
            .putString(K_COND, s.condition.name)
            .putBoolean(K_DAY, s.isDay)
            .putLong(K_UPDATED, s.updatedAt)
            .putLong(K_SUNRISE, s.sunriseMs ?: 0L)
            .putLong(K_SUNSET, s.sunsetMs ?: 0L)
            .apply()
    }

    private fun parseLocalTime(text: String?, offsetSeconds: Int): Long? {
        if (text.isNullOrBlank()) return null
        return runCatching {
            LocalDateTime.parse(text).toEpochSecond(ZoneOffset.ofTotalSeconds(offsetSeconds)) * 1000L
        }.getOrNull()
    }

    /**
     * Android 10+ da ilova fonda bo'lsa getLastKnownLocation() ruxsat bor bo'lsa ham null qaytaradi
     * (ACCESS_BACKGROUND_LOCATION kerak). Shuning uchun ilova ochiq paytda koordinatani saqlab qo'yamiz
     * ([rememberLocation]) va WorkManager fonda shu saqlangan qiymatni ishlatadi.
     */
    @SuppressLint("MissingPermission")
    fun rememberLocation() {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) return
        val lm = context.getSystemService(LocationManager::class.java)
        lm.getProviders(true)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
            ?.let { prefs.edit().putString(K_LAT, it.latitude.toString()).putString(K_LON, it.longitude.toString()).apply() }
    }

    private fun lastKnownLocation(): Pair<Double, Double> {
        rememberLocation()   // ilova oldingi planda bo'lsa yangilanadi, aks holda hech narsa o'zgarmaydi
        val lat = prefs.getString(K_LAT, null)?.toDoubleOrNull()
        val lon = prefs.getString(K_LON, null)?.toDoubleOrNull()
        return if (lat != null && lon != null) lat to lon else DEFAULT_LAT to DEFAULT_LON
    }

    private companion object {
        const val K_TEMP = "temp"
        const val K_COND = "cond"
        const val K_DAY = "day"
        const val K_UPDATED = "updated"
        const val K_SUNRISE = "sunrise"
        const val K_SUNSET = "sunset"
        const val K_LAT = "lat"
        const val K_LON = "lon"
        const val DEFAULT_LAT = 41.2995   // Toshkent
        const val DEFAULT_LON = 69.2401
    }
}
