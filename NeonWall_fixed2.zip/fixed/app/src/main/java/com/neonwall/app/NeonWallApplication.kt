package com.neonwall.app

import android.app.Application
import com.neonwall.app.data.WeatherRepository
import com.neonwall.app.widget.RefreshWorker

/** Ilova ishga tushganda fon yangilanishlarini rejalashtiradi (ob-havo + vidjetlar). */
class NeonWallApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        RefreshWorker.schedule(this)
        if (WeatherRepository(this).cached() == null) RefreshWorker.runNow(this)
    }
}
