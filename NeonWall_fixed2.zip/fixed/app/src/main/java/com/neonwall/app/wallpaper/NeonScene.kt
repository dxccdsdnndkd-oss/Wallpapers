package com.neonwall.app.wallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import com.neonwall.app.data.AccentMode
import com.neonwall.app.data.WallpaperSettings
import com.neonwall.app.data.WeatherCondition
import com.neonwall.app.power.RenderPolicy
import kotlin.math.sin
import kotlin.random.Random

/**
 * Sahna: barcha qatlamlarni chizadi. Android'ning hech qanday servisiga bog'liq emas,
 * shuning uchun mantiq Engine'dan ajratilgan (testlash va qayta ishlatish oson).
 *
 * Qatlamlar (orqadan oldinga):
 *  1. Fon gradienti (kun vaqti palitrasi)   2. Neon "orb"lar   3. Perspektiv panjara + gorizont nuri
 *  4. Zarrachalar (3 chuqurlik)             5. Audio spektr    6. Ob-havo (yomg'ir/qor)
 *  7. Teginish to'lqinlari (ripple)
 */
class NeonScene(private val density: Float) {

    // ---- Engine tomonidan beriladigan kirishlar ----
    var settings = WallpaperSettings()
    var policy = RenderPolicy(60, true, 1f, "")
    var palette: ScenePalette = DayNightPalette.NIGHT
    var weather: WeatherCondition? = null
    var audioLevels: FloatArray = FloatArray(0)
    var audioEnergy = 0f

    var width = 0f
        private set
    var height = 0f
        private set

    private val glow = GlowSprite()
    private val primaryGlow = TintedPaint()
    private val secondaryGlow = TintedPaint()
    private val particles = ParticleField(MAX_PARTICLES)

    private val bgPaint = Paint()
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
    }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1.5f * density
        strokeCap = Paint.Cap.ROUND
    }

    private val hsv = FloatArray(3)
    private val gridLines = FloatArray(64)
    private val rainX = FloatArray(MAX_RAIN)
    private val rainY = FloatArray(MAX_RAIN)
    private val rainSpeed = FloatArray(MAX_RAIN)
    private val rainLines = FloatArray(MAX_RAIN * 4)

    private class Ripple(val x: Float, val y: Float) { var age = 0f }
    private val ripples = ArrayList<Ripple>(MAX_RIPPLES)

    private var time = 0f
    private var gridScroll = 0f
    private var bgTop = 0
    private var bgBottom = 0
    private var horizonY = 0f

    fun onSizeChanged(w: Float, h: Float) {
        width = w
        height = h
        particles.resize(w, h)
        for (i in 0 until MAX_RAIN) {
            rainX[i] = Random.nextFloat() * w
            rainY[i] = Random.nextFloat() * h
            rainSpeed[i] = 0.7f + Random.nextFloat() * 0.6f
        }
        bgTop = 0   // gradient shader qayta quriladi
    }

    fun addTouch(x: Float, y: Float) {
        if (!settings.touchEnabled) return
        if (ripples.size >= MAX_RIPPLES) ripples.removeAt(0)
        ripples.add(Ripple(x, y))
        particles.push(x, y, radius = 320f * density / 3f, strength = 900f)
    }

    fun update(dt: Float, t: Float) {
        time = t
        gridScroll = (gridScroll + dt * (0.10f + audioEnergy * 0.9f)) % 1f
        particles.activeCount =
            (MAX_PARTICLES * settings.particleDensity * policy.densityScale).toInt().coerceIn(0, MAX_PARTICLES)
        particles.update(dt, audioEnergy, t)
        updateRain(dt)
        var i = ripples.size - 1
        while (i >= 0) {
            val r = ripples[i]
            r.age += dt
            if (r.age > RIPPLE_LIFE) ripples.removeAt(i)
            i--
        }
    }

    fun draw(canvas: Canvas, offX: Float, offY: Float) {
        if (width <= 0f) return
        val primary = primaryColor()
        val secondary = secondaryColor(primary)
        primaryGlow.tint(primary)
        secondaryGlow.tint(secondary)
        horizonY = height * 0.62f + offY * 0.25f

        drawBackground(canvas)
        drawOrbs(canvas, offX, offY)
        drawGrid(canvas, offX)
        particles.draw(
            canvas, glow, primaryGlow, secondaryGlow, offX, offY, time,
            alphaScale = 0.25f + 0.75f * palette.starAlpha, density = density,
        )
        drawSpectrum(canvas, primary, secondary)
        drawWeather(canvas, primary)
        drawRipples(canvas, primary, secondary)
    }

    // ---------------- qatlamlar ----------------

    private fun drawBackground(canvas: Canvas) {
        if (bgTop != palette.skyTop || bgBottom != palette.skyBottom) {
            bgTop = palette.skyTop
            bgBottom = palette.skyBottom
            bgPaint.shader = LinearGradient(0f, 0f, 0f, height, bgTop, bgBottom, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, width, height, bgPaint)
    }

    private fun drawOrbs(canvas: Canvas, offX: Float, offY: Float) {
        val pulse = 1f + audioEnergy * 0.8f
        primaryGlow.paint.alpha = (70f * palette.glow * pulse).toInt().coerceIn(0, 255)
        glow.draw(canvas, width * 0.72f + offX * 0.5f, height * 0.22f + offY * 0.5f, width * 0.55f * pulse, primaryGlow.paint)
        secondaryGlow.paint.alpha = (45f * palette.glow * pulse).toInt().coerceIn(0, 255)
        glow.draw(canvas, width * 0.2f + offX * 0.4f, height * 0.48f + offY * 0.4f, width * 0.45f, secondaryGlow.paint)
    }

    private fun drawGrid(canvas: Canvas, offX: Float) {
        val vanishX = width / 2f + offX * 0.6f
        val g = palette.glow

        // gorizont nuri: sprite'ni vertikal siqib chizamiz
        canvas.save()
        canvas.scale(1f, 0.14f, vanishX, horizonY)
        primaryGlow.paint.alpha = (150f * g * (1f + audioEnergy)).toInt().coerceIn(0, 255)
        glow.draw(canvas, vanishX, horizonY, width * 0.75f, primaryGlow.paint)
        canvas.restore()

        // vertikal chiziqlar (yo'qolish nuqtasidan)
        gridPaint.color = palette.grid
        gridPaint.alpha = (80f * g).toInt().coerceIn(0, 255)
        val cols = 14
        val spread = width * 2.2f
        var n = 0
        for (i in -cols / 2..cols / 2) {
            gridLines[n++] = vanishX
            gridLines[n++] = horizonY
            gridLines[n++] = vanishX + i * (spread / cols)
            gridLines[n++] = height + 10f
        }
        canvas.drawLines(gridLines, 0, n, gridPaint)

        // gorizontal chiziqlar (perspektiv: y ~ t^2) — oldinga qarab siljiydi
        val rows = 12
        for (k in 0 until rows) {
            val t = (k + gridScroll) / rows
            val y = horizonY + (height - horizonY + 10f) * t * t
            gridPaint.alpha = ((30f + 150f * t) * g).toInt().coerceIn(0, 255)
            canvas.drawLine(0f, y, width, y, gridPaint)
        }
    }

    private fun drawSpectrum(canvas: Canvas, primary: Int, secondary: Int) {
        if (!settings.audioEnabled || audioLevels.isEmpty()) return
        val n = audioLevels.size
        val slot = width / n
        val barW = slot * 0.55f
        val maxH = height * 0.18f
        for (i in 0 until n) {
            val level = audioLevels[i]
            if (level < 0.02f) continue
            val h = level * maxH
            val left = i * slot + (slot - barW) / 2f
            barPaint.color = ColorUtils.blendARGB(primary, secondary, i / (n - 1f))
            barPaint.alpha = 210
            canvas.drawRoundRect(left, horizonY - h, left + barW, horizonY, barW / 2f, barW / 2f, barPaint)
            barPaint.alpha = 70                                  // pastki "aks"
            canvas.drawRoundRect(left, horizonY, left + barW, horizonY + h * 0.5f, barW / 2f, barW / 2f, barPaint)
            if (level > 0.55f) {                                 // baland chiziq uchida porlash
                primaryGlow.paint.alpha = 140
                glow.draw(canvas, left + barW / 2f, horizonY - h, barW * 2.2f, primaryGlow.paint)
            }
        }
    }

    private fun isPrecipitation() =
        weather == WeatherCondition.RAIN || weather == WeatherCondition.STORM || weather == WeatherCondition.SNOW

    private fun updateRain(dt: Float) {
        if (!isPrecipitation()) return
        val fall = if (weather == WeatherCondition.SNOW) 120f else 1100f
        for (i in 0 until rainCount()) {
            rainY[i] += rainSpeed[i] * fall * dt
            if (rainY[i] > height) {
                rainY[i] = -30f
                rainX[i] = Random.nextFloat() * width
            }
        }
    }

    private fun rainCount() = (MAX_RAIN * policy.densityScale).toInt().coerceIn(0, MAX_RAIN)

    private fun drawWeather(canvas: Canvas, primary: Int) {
        if (!isPrecipitation()) return
        rainPaint.color = primary
        rainPaint.alpha = 90
        val count = rainCount()
        if (weather == WeatherCondition.SNOW) {
            for (i in 0 until count) {
                canvas.drawCircle(rainX[i] + sin(time + i) * 8f * density, rainY[i], 1.6f * density, rainPaint)
            }
        } else {
            var n = 0
            for (i in 0 until count) {
                rainLines[n++] = rainX[i]
                rainLines[n++] = rainY[i]
                rainLines[n++] = rainX[i] - 5f * density
                rainLines[n++] = rainY[i] + 22f * density
            }
            canvas.drawLines(rainLines, 0, n, rainPaint)
        }
    }

    private fun drawRipples(canvas: Canvas, primary: Int, secondary: Int) {
        for (i in 0 until ripples.size) {
            val r = ripples[i]
            val p = r.age / RIPPLE_LIFE
            val alpha = ((1f - p) * 255f).toInt().coerceIn(0, 255)
            val radius = (40f + p * width * 0.35f)
            ripplePaint.strokeWidth = (3f * (1f - p) + 1f) * density
            ripplePaint.color = primary
            ripplePaint.alpha = alpha
            canvas.drawCircle(r.x, r.y, radius, ripplePaint)
            ripplePaint.color = secondary
            ripplePaint.alpha = (alpha * 0.6f).toInt()
            canvas.drawCircle(r.x, r.y, radius * 0.65f, ripplePaint)
            if (p < 0.35f) {                                     // boshlang'ich yorqin chaqnash
                primaryGlow.paint.alpha = ((0.35f - p) / 0.35f * 200f).toInt().coerceIn(0, 255)
                glow.draw(canvas, r.x, r.y, 110f * density, primaryGlow.paint)
            }
        }
    }

    // ---------------- ranglar ----------------

    private fun primaryColor(): Int = when (settings.accent) {
        AccentMode.AUTO -> palette.primary
        AccentMode.CYAN -> 0xFF00E5FF.toInt()
        AccentMode.MAGENTA -> 0xFFFF2BD6.toInt()
        AccentMode.LIME -> 0xFF76FF03.toInt()
        AccentMode.AMBER -> 0xFFFFAB00.toInt()
    }

    private fun secondaryColor(primary: Int): Int {
        if (settings.accent == AccentMode.AUTO) return palette.secondary
        Color.colorToHSV(primary, hsv)   // hsv qayta ishlatiladi: har kadrda yangi massiv yaratilmaydi
        hsv[0] = (hsv[0] + 150f) % 360f      // komplementarga yaqin burilish
        return Color.HSVToColor(hsv)
    }

    private companion object {
        const val MAX_PARTICLES = 220
        const val MAX_RAIN = 90
        const val MAX_RIPPLES = 8
        const val RIPPLE_LIFE = 1.2f
    }
}
