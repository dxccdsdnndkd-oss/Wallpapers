package com.neonwall.app.widget

import android.content.Context
import android.widget.RemoteViews
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.AndroidRemoteViews
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.neonwall.app.MainActivity
import com.neonwall.app.R
import com.neonwall.app.data.WeatherRepository
import com.neonwall.app.data.WeatherSnapshot
import com.neonwall.app.ui.theme.Neon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Neon raqamli soat (TextClock, o'zi yangilanadi) + ob-havo qatori. */
class ClockWeatherWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        // provideGlance main thread'da ishlaydi (hujjat) => disk o'qishni IO'ga o'tkazamiz
        val weather = withContext(Dispatchers.IO) { WeatherRepository(context).cached() }
        provideContent { ClockWeatherContent(context, weather) }
    }
}

@Composable
private fun ClockWeatherContent(context: Context, weather: WeatherSnapshot?) {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.bg_widget_glass))
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clickable(actionStartActivity<MainActivity>()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalAlignment = Alignment.Start,
    ) {
        AndroidRemoteViews(
            remoteViews = RemoteViews(context.packageName, R.layout.widget_clock_digital),
            modifier = GlanceModifier.fillMaxWidth(),
        )
        Row(
            modifier = GlanceModifier.padding(start = 8.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = weather?.condition?.glyph ?: "◌",
                style = TextStyle(color = ColorProvider(Neon.Magenta), fontSize = 22.sp),
            )
            Spacer(GlanceModifier.width(8.dp))
            Text(
                text = weather?.let { "${it.tempC.roundToInt()}°C  ·  ${it.condition.label}" }
                    ?: "Weather: waiting for data…",
                style = TextStyle(
                    color = ColorProvider(Neon.TextPrimary),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                ),
            )
        }
    }
}

class ClockWeatherWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ClockWeatherWidget()
}
