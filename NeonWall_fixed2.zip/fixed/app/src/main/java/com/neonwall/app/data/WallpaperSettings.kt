package com.neonwall.app.data

enum class AccentMode(val label: String) {
    AUTO("Auto"), CYAN("Cyan"), MAGENTA("Magenta"), LIME("Lime"), AMBER("Amber")
}

/** Ilova UI va wallpaper engine o'rtasida umumiy sozlamalar (yagona haqiqat manbai). */
data class WallpaperSettings(
    val parallaxEnabled: Boolean = true,
    val parallaxStrength: Float = 0.5f,   // 0..1
    val touchEnabled: Boolean = true,
    val audioEnabled: Boolean = true,
    val dayNightEnabled: Boolean = true,
    val particleDensity: Float = 0.6f,    // 0..1
    val maxFps: Int = 120,
    val accent: AccentMode = AccentMode.AUTO,
    val batteryThreshold: Int = 20,       // % — shundan pastda FPS 30 ga tushadi
    val gameMode: Boolean = false,        // true: animatsiya to'liq to'xtaydi
)
