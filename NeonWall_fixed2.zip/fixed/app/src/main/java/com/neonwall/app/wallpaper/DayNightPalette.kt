package com.neonwall.app.wallpaper

import androidx.core.graphics.ColorUtils
import com.neonwall.app.data.WeatherCondition

data class ScenePalette(
    val skyTop: Int,
    val skyBottom: Int,
    val primary: Int,
    val secondary: Int,
    val grid: Int,
    val starAlpha: Float,   // zarrachalar ko'rinishi (kunduzi kamayadi)
    val glow: Float,        // umumiy yorug'lik kuchi
)

/** Quyosh chiqishi/botishi, qurilma mahalliy vaqtida soat sifatida (masalan 6.58f). */
data class SunHours(val sunrise: Float, val sunset: Float)

/** Kun vaqti + ob-havo bo'yicha palitra. AMOLED uchun fon doim qora/to'q bo'lib qoladi. */
object DayNightPalette {

    val NIGHT = ScenePalette(
        0xFF000000.toInt(), 0xFF050A1A.toInt(), 0xFF00E5FF.toInt(), 0xFFFF2BD6.toInt(), 0xFF00B8D4.toInt(), 1f, 1f,
    )
    private val DAWN = ScenePalette(
        0xFF0A0616.toInt(), 0xFF2A0F3D.toInt(), 0xFFFF8A65.toInt(), 0xFFFF2BD6.toInt(), 0xFFFF6E40.toInt(), 0.5f, 0.9f,
    )
    private val DAY = ScenePalette(
        0xFF02121C.toInt(), 0xFF0B3A4A.toInt(), 0xFF18FFFF.toInt(), 0xFF76FF03.toInt(), 0xFF00E5FF.toInt(), 0.15f, 0.8f,
    )
    private val DUSK = ScenePalette(
        0xFF0B0418.toInt(), 0xFF3D0B3A.toInt(), 0xFFFF4081.toInt(), 0xFFFFAB00.toInt(), 0xFFFF4081.toInt(), 0.6f, 1f,
    )

    // (soat, palitra) — oraliqlar chiziqli aralashtiriladi. Quyosh vaqti noma'lum bo'lsa — qat'iy jadval.
    private val fixedKeyframes = listOf(
        0f to NIGHT, 5f to NIGHT, 6.5f to DAWN, 9f to DAY,
        16.5f to DAY, 18.5f to DUSK, 20.5f to NIGHT, 24f to NIGHT,
    )

    // Oxirgi hisoblangan jadval keshlanadi (at() har ~10 s da chaqiriladi, allocation kerak emas)
    private var cachedSun: SunHours? = null
    private var cachedFrames: List<Pair<Float, ScenePalette>> = fixedKeyframes

    /**
     * Haqiqiy quyosh vaqtiga bog'langan jadval. Eski qat'iy jadvaldagi oraliqlar saqlangan:
     * tun tugashi = chiqishdan 1.5 s oldin, DAWN = chiqish, DAY = chiqish+2.5 s,
     * DAY tugashi = botishdan 2 s oldin, DUSK = botish, NIGHT = botish+2 s.
     */
    private fun keyframesFor(sun: SunHours?): List<Pair<Float, ScenePalette>> {
        if (sun == null) return fixedKeyframes
        if (sun == cachedSun) return cachedFrames
        val r = sun.sunrise
        val t = sun.sunset
        val hours = floatArrayOf(r - 1.5f, r, r + 2.5f, t - 2f, t, t + 2f)
        // Qutb yaqinida / noto'g'ri ma'lumotda jadval buzilmasin: tartib va 0..24 oralig'ini tekshiramiz
        val valid = hours.first() > 0f && hours.last() < 24f && (1 until hours.size).all { hours[it] > hours[it - 1] }
        val frames = if (!valid) fixedKeyframes else listOf(
            0f to NIGHT, hours[0] to NIGHT, hours[1] to DAWN, hours[2] to DAY,
            hours[3] to DAY, hours[4] to DUSK, hours[5] to NIGHT, 24f to NIGHT,
        )
        cachedSun = sun
        cachedFrames = frames
        return frames
    }

    fun at(hour: Float, weather: WeatherCondition?, sun: SunHours? = null): ScenePalette {
        val keyframes = keyframesFor(sun)
        val h = hour.coerceIn(0f, 24f)
        val idx = keyframes.indexOfLast { it.first <= h }.coerceAtMost(keyframes.size - 2)
        val (h0, p0) = keyframes[idx]
        val (h1, p1) = keyframes[idx + 1]
        val t = ((h - h0) / (h1 - h0)).coerceIn(0f, 1f)
        return applyWeather(mix(p0, p1, t), weather)
    }

    private fun mix(a: ScenePalette, b: ScenePalette, t: Float) = ScenePalette(
        skyTop = ColorUtils.blendARGB(a.skyTop, b.skyTop, t),
        skyBottom = ColorUtils.blendARGB(a.skyBottom, b.skyBottom, t),
        primary = ColorUtils.blendARGB(a.primary, b.primary, t),
        secondary = ColorUtils.blendARGB(a.secondary, b.secondary, t),
        grid = ColorUtils.blendARGB(a.grid, b.grid, t),
        starAlpha = a.starAlpha + (b.starAlpha - a.starAlpha) * t,
        glow = a.glow + (b.glow - a.glow) * t,
    )

    private fun applyWeather(p: ScenePalette, w: WeatherCondition?): ScenePalette {
        val (grey, dim) = when (w) {
            WeatherCondition.RAIN, WeatherCondition.STORM -> 0.45f to 0.75f
            WeatherCondition.SNOW -> 0.35f to 0.80f
            WeatherCondition.FOG -> 0.55f to 0.60f
            WeatherCondition.CLOUDY -> 0.25f to 0.85f
            else -> return p
        }
        val steel = 0xFF5C8DFF.toInt()
        return p.copy(
            skyBottom = ColorUtils.blendARGB(p.skyBottom, 0xFF0A1220.toInt(), grey),
            primary = ColorUtils.blendARGB(p.primary, steel, grey * 0.5f),
            grid = ColorUtils.blendARGB(p.grid, steel, grey * 0.5f),
            starAlpha = p.starAlpha * (1f - grey),
            glow = p.glow * dim,
        )
    }
}
