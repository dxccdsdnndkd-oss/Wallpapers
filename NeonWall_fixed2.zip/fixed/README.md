# NeonWall — Live Wallpaper & Interactive Widgets (Kotlin / Compose / Glance)

## Tuzilma
- `wallpaper/` — NeonWallpaperService (Choreographer + lockHardwareCanvas), NeonScene, ParticleField, ParallaxSensor, AudioReactor, DayNightPalette
- `widget/` — Glance vidjetlar (Clock+Weather, System Monitor, Music) + WidgetRefresher/RefreshWorker
- `media/` — MediaListenerService (hozir chalinayotgan musiqa)
- `power/` — PowerPolicy (batareya / thermal / game mode -> FPS qarori)
- `data/` — sozlamalar, ob-havo (Open-Meteo), tizim statistikasi
- `ui/` — Compose UI (glassmorphism + AMOLED neon)

## Build
1. Android Studio (Ladybug yoki yangiroq) da `NeonWall` papkasini oching, Gradle sync kuting.
2. Qurilmada USB debugging yoqing -> Run ▶ (yoki Build > Build APK(s)).
3. APK: `app/build/outputs/apk/debug/app-debug.apk`
4. Release: `./gradlew assembleRelease` -> `app/build/outputs/apk/release/` (hozir debug kalit bilan imzolanadi).
5. `gradlew`, `gradlew.bat` va `gradle-wrapper.jar` qo'shilgan (terminalda `./gradlew assembleDebug`). JDK 17 kerak (Android Studio'ning o'z JBR'i mos).
6. Notification access (musiqa vidjeti): APK'ni fayl sifatida o'rnatgan bo'lsangiz, Android 13+ da kalit kulrang bo'lishi mumkin:
   Sozlamalar > Ilovalar > NeonWall > yuqori o'ng "⋮" > "Cheklangan sozlamalarga ruxsat berish", so'ng qayta urinib ko'ring.

## Ma'lum cheklovlar
- Kod kompilyatsiya qilib sinalmagan: birinchi build'da kichik xatolar chiqishi mumkin.
- CPU %: Android 8+ da /proc/stat ko'pincha yopiq; cpufreq nisbati yoki "—" ko'rsatiladi.
- Teginish: ba'zi launcher'lar (jumladan Xiaomi/Poco) wallpaper'ga tegishni yubormaydi; tap komandasi fallback sifatida ishlatilgan.
- Visualizer: ba'zi qurilmalarda nol signal qaytadi; u holda sintetik puls ko'rsatiladi.
- O'yin rejimi qo'lda yoqiladi (avtomatik aniqlash uchun UsageStats ruxsati kerak bo'ladi).

## 1-bosqich o'zgarishlari (statik tekshiruv; kompilyator bilan sinalmagan)
- Glance: `actionStartActivity` importi `androidx.glance.appwidget.action` paketiga to'g'rilandi (3 vidjet fayli).
- Vidjetlar: `provideGlance` ichidagi disk/IO ishlari `Dispatchers.IO` ga ko'chirildi; media tugmalariga eventTime qo'shildi.
- NeonWallpaperService: surface qayta yaratilgandan keyin sikl tiklanadi; Choreographer'da bitta callback kafolati;
  FPS tolerance VSYNC'ga nisbatan; unlockCanvasAndPost himoyalandi; vaqt 1 soatda o'raladi.
- ParallaxSensor: silliqlash sensor (50 Hz) emas, kadr (120+ Hz) bo'yicha.
- AudioReactor: o'chiq holatda sintetik puls ishlamaydi; Visualizer oqishi tuzatildi; ruxsat keyin berilsa qayta uriniladi.
- MediaListenerService: requestRebind, yozuvlar Mutex bilan ketma-ket, sessiya o'lganda qayta skanerlash.
- Ob-havo: fon ishchisi uchun joylashuv keshlanadi (Android 10+ da fonda getLastKnownLocation null qaytaradi).
- A: DayNightPalette Open-Meteo `daily=sunrise,sunset` ga bog'landi.
- R8: ActionCallback uchun keep qoidasi qo'shildi.

## 1-bosqich (2-o'tish): qo'lda "kompilyator" tekshiruvi
Bu muhitda Maven/Google/Gradle serverlari yopiq va Android SDK yo'q, shuning uchun kod HAQIQIY kompilyatsiya qilinmadi.
Barcha 26 ta Kotlin fayl, Manifest, resurslar va Gradle fayllari satrma-satr o'qildi.
- AudioReactor: `time` soatiga bir marta 0 ga o'ralgani uchun `isMusicActive` tekshiruvi abadiy qotib qolardi (musiqa holati yangilanmasdi) — tuzatildi.
- MediaListenerService: `catch (_: …)` -> nomli parametr; `requestRebind` klass nomi bilan chaqiriladi.
- NeonScene: har kadrda `FloatArray(3)` yaratilishi (accent != AUTO) olib tashlandi.
- NeonWallpaperService: animatsiya to'xtatilganda launcher sahifasi almashsa, bitta kadr qayta chiziladi.
- Gradle wrapper (gradlew, gradlew.bat, jar) qo'shildi.

## Maxfiylik
Ilova faqat ob-havo uchun `api.open-meteo.com` ga so'rov yuboradi (koordinata yoki Toshkent). Boshqa hech narsa internetga chiqmaydi.
