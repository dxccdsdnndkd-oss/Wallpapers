# NeonWall 2.0 — 1-bosqich

## 1-bosqich tarkibi
- Iliq mineral ranglar tizimi, 6 ta aksent varianti, AMOLED qora va Android 12+ Material You rejimi.
- Uzbek (Latin) tilidagi yangi kutubxona interfeysi: jonli sahnalar, qidiruv, kategoriya filtrlari va sevimlilar.
- 20 ta sahna kartasi: Qutb shu’lasi, yomg‘ir oynasi, qor, sakura, yulduzlar, galaktika, cho‘g‘, bo‘ron, okean, chiroqchalar, pufakchalar, lava lampasi, gradient to‘lqinlari, raqamli yomg‘ir, tungi shahar, bulutlar, geometriya, kun/tun va boshqalar.
- 20 ta original, dasturiy yaratilgan statik fon `app/src/main/assets/wallpapers/` ichida. `app/src/main/assets/LICENSES.txt` litsenziya ma’lumotlarini beradi.
- Yangi vektor launcher belgisi.

## Build (Android Studio/PC talab qilinmaydi)
GitHub Actions workflow'da JDK 17 o‘rnating va quyidagini ishga tushiring:

```bash
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Yangi dependency
Bu bosqichda yangi Gradle dependency qo‘shilmadi. Mavjud Compose, Material 3 va Android API'lari ishlatiladi.

## Cheklovlar va keyingi ishlar
- Ushbu bosqich kutubxona navigatsiyasi, rang tanlovi, sevimlilar va original statik fonlarni taqdim etadi. Jonli sahna kartalari katalog/metama’lumot va vizual preview vazifasini bajaradi; 20 sahnaning alohida to‘liq render mexanizmlari va har sahnaga 3–5 parametrli editor keyingi iteratsiyada ulanadi.
- Statik fonni bosish uni Android `WallpaperManager` orqali bosh ekranga o‘rnatishga urinadi. Qurilma/ROM xatosi bo‘lsa xabar ko‘rsatiladi.
- Material You faqat Android 12+ da mavjud. HyperOS ranglarni tizim darajasida o‘zgartirishi mumkin.
- Bu ish muhiti Gradle distributivini internetdan yuklay olmadi (`services.gradle.org` DNS/ulanish xatosi), shu sababli bu yerda haqiqiy `assembleDebug` natijasi olinmadi. GitHub Actions build'i hali tasdiqlanmagan.
