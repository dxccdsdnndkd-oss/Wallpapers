package com.neonwall.app.media

import android.app.WallpaperManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neonwall.app.ui.components.GlassCard
import com.neonwall.app.ui.components.NeonButton
import com.neonwall.app.ui.components.ScreenColumn
import com.neonwall.app.ui.components.ScreenHeader

@Composable
fun PhotoLiveScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PhotoWallpaperRenderer.PREFS, 0) }
    var selectedUri by rememberSaveable { mutableStateOf(prefs.getString(PhotoWallpaperRenderer.KEY_URI, null)) }
    var kenBurns by remember { mutableStateOf(prefs.getBoolean(PhotoWallpaperRenderer.KEY_KEN_BURNS, true)) }
    var particles by remember { mutableStateOf(prefs.getBoolean(PhotoWallpaperRenderer.KEY_PARTICLES, false)) }
    var vignette by remember { mutableStateOf(prefs.getBoolean(PhotoWallpaperRenderer.KEY_VIGNETTE, false)) }
    var intensity by remember { mutableStateOf(prefs.getFloat("particle_intensity", 0.5f)) }
    var filter by remember { mutableStateOf(prefs.getString(PhotoWallpaperRenderer.KEY_FILTER, PhotoWallpaperRenderer.FILTER_NONE) ?: PhotoWallpaperRenderer.FILTER_NONE) }
    var previewBitmap by remember(selectedUri) {
        mutableStateOf(selectedUri?.let { uri -> runCatching {
            val parsed = Uri.parse(uri)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(parsed)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val sample = maxOf(1, maxOf(bounds.outWidth / 1200, bounds.outHeight / 1800))
            val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = android.graphics.Bitmap.Config.RGB_565 }
            context.contentResolver.openInputStream(parsed)?.use { BitmapFactory.decodeStream(it, null, options)?.asImageBitmap() }
        }.getOrNull() })
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            selectedUri = uri.toString()
            prefs.edit().putString(PhotoWallpaperRenderer.KEY_URI, uri.toString()).putBoolean(PhotoWallpaperRenderer.KEY_ENABLED, true).apply()
        }
    }
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) Toast.makeText(context, "Media tanlandi. Video/GIF jonli ijrosi keyingi media-renderer yangilanishida qo‘shiladi.", Toast.LENGTH_LONG).show()
    }
    ScreenColumn {
        ScreenHeader("PHOTO → LIVE", "Rasmingizga mayin harakat va effektlar qo‘shing")
        GlassCard {
            Box(Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                if (previewBitmap != null) Image(previewBitmap!!, contentDescription = "Tanlangan surat", modifier = Modifier.fillMaxWidth().height(300.dp), contentScale = ContentScale.Crop)
                else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("▧", fontSize = 48.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Galereyadan surat tanlang", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(12.dp))
            NeonButton("GALEREYADAN SURAT TANLASH") { imagePicker.launch(arrayOf("image/*")) }
        }
        GlassCard {
            Text("Harakat", color = MaterialTheme.colorScheme.onSurface, fontSize = 17.sp)
            SettingSwitch("Ken Burns — sekin yaqinlashish", kenBurns) {
                kenBurns = it; prefs.edit().putBoolean(PhotoWallpaperRenderer.KEY_KEN_BURNS, it).apply()
            }
            SettingSwitch("Zarrachalar (chang/yulduzlar)", particles) {
                particles = it; prefs.edit().putBoolean(PhotoWallpaperRenderer.KEY_PARTICLES, it).apply()
            }
            SettingSwitch("Qorong‘i chetlar (vignette)", vignette) {
                vignette = it; prefs.edit().putBoolean(PhotoWallpaperRenderer.KEY_VIGNETTE, it).apply()
            }
            Text("Zarracha zichligi · ${(intensity * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
            Slider(value = intensity, onValueChange = { intensity = it; prefs.edit().putFloat("particle_intensity", it).apply() }, valueRange = 0f..1f)
        }
        GlassCard {
            Text("Rang filtri", color = MaterialTheme.colorScheme.onSurface, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Asl" to "none", "Iliq" to "warm", "Sovuq" to "cool", "Oq-qora" to "mono").forEach { (label, key) ->
                    FilterChip(selected = filter == key, onClick = { filter = key; prefs.edit().putString(PhotoWallpaperRenderer.KEY_FILTER, key).apply() }, label = { Text(label, fontSize = 12.sp) })
                }
            }
        }
        GlassCard {
            Text("Video va GIF", color = MaterialTheme.colorScheme.onSurface, fontSize = 17.sp)
            Text("Video/GIF faylini tanlash keyingi media-renderer qismiga tayyorlanadi. Ushbu bosqichda jonli fon sifatida surat, animatsiya va rang filtrlari ishlaydi.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            NeonButton("VIDEO / GIF TANLASH") { mediaPicker.launch(arrayOf("video/*", "image/gif", "image/webp")) }
        }
        NeonButton("JONLI SURAT FONINI O‘RNATISH") {
            if (selectedUri.isNullOrBlank()) Toast.makeText(context, "Avval surat tanlang", Toast.LENGTH_SHORT).show()
            else {
                prefs.edit().putBoolean(PhotoWallpaperRenderer.KEY_ENABLED, true).apply()
                runCatching { context.startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, android.content.ComponentName(context, com.neonwall.app.wallpaper.NeonWallpaperService::class.java))
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }) }.onFailure { Toast.makeText(context, "Jonli fon sozlamasini ochib bo‘lmadi", Toast.LENGTH_LONG).show() }
            }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(end = 8.dp))
        Switch(checked = checked, onCheckedChange = onChange, modifier = Modifier.size(width = 52.dp, height = 32.dp))
    }
}
