package com.neonwall.app.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/** NeonWall 2.0: iliq mineral ranglar va bitta mis aksenti. */
object Neon {
    val Cyan = Color(0xFFD99A68)       // mavjud API nomi saqlangan; endi iliq mis aksenti
    val Magenta = Color(0xFF879B87)    // yumshoq sage ikkilamchi rang
    val Lime = Color(0xFFC5B77D)
    val Amber = Color(0xFFE1B77E)
    val Void = Color(0xFF10110F)
    val Surface = Color(0xFF1B1D19)
    val TextPrimary = Color(0xFFF1EEE6)
    val TextDim = Color(0xFFAAA99F)
}

@Composable
fun NeonWallTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dynamic = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) dynamicDarkColorScheme(context) else null
    val prefs = context.getSharedPreferences("neonwall_library", 0)
    val useDynamic = prefs.getBoolean("dynamic_color", false)
    val useAmoled = prefs.getBoolean("amoled_black", true)
    val paletteAccent = when (prefs.getInt("palette_index", 0)) {
        1 -> Color(0xFF879B87)
        2 -> Color(0xFFE1B77E)
        3 -> Color(0xFF8CA9C4)
        4 -> Color(0xFFC18B91)
        5 -> Color(0xFFA99AC7)
        else -> Neon.Cyan
    }
    val scheme = darkColorScheme(
        primary = if (useDynamic) dynamic?.primary ?: paletteAccent else paletteAccent,
        onPrimary = Color(0xFF17130F),
        secondary = if (useDynamic) dynamic?.secondary ?: Neon.Magenta else paletteAccent.copy(alpha = 0.88f),
        tertiary = Neon.Lime,
        background = if (useAmoled) Color.Black else Neon.Void,
        surface = if (useAmoled) Color(0xFF090A09) else Neon.Surface,
        onBackground = Neon.TextPrimary,
        onSurface = Neon.TextPrimary,
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
