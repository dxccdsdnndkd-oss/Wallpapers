package com.neonwall.app.wallpaper

import android.app.WallpaperManager
import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import com.neonwall.app.data.SettingsRepository
import com.neonwall.app.media.PhotoWallpaperRenderer
import com.neonwall.app.data.WeatherRepository
import com.neonwall.app.data.WeatherSnapshot
import com.neonwall.app.power.DisplayInfo
import com.neonwall.app.power.PowerPolicyEvaluator
import com.neonwall.app.widget.WidgetRefresher
import java.util.Calendar

/**
 * Live wallpaper.
 *
 * Render sikli: Choreographer (VSYNC bilan sinxron => 120/144 Hz da silliq) + FPS limiter.
 * Surface.setFrameRate() bilan tizimga ham kerakli chastota haqida "maslahat" beriladi,
 * shunda LTPO/VRR panel ortiqcha yuqori chastotada ishlamaydi (batareya tejaladi).
 *
 * Hammasi main thread'da: lockHardwareCanvas() GPU orqali chizadi, mantiq esa juda yengil.
 */
class NeonWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = NeonEngine()

    private inner class NeonEngine : Engine() {

        private val appContext = applicationContext
        private val handler = Handler(Looper.getMainLooper())
        private val choreographer = Choreographer.getInstance()
        private val settingsRepo = SettingsRepository(appContext)
        private val weatherRepo = WeatherRepository(appContext)
        private val policyEvaluator = PowerPolicyEvaluator(appContext)
        private val scene = NeonScene(resources.displayMetrics.density)
        private val sensor = ParallaxSensor(appContext)
        private val audio = AudioReactor(appContext)
        private val photoRenderer = PhotoWallpaperRenderer(appContext)

        private var visible = false
        private var running = false
        private var lastFrameNs = 0L
        private var timeSec = 0f
        private var displayHz = 60
        private var pageOffset = 0.5f
        private var lastMoveTouchMs = 0L

        // Choreographer'da bir vaqtning o'zida faqat BITTA callback bo'lishini kafolatlaydi (ikki marta post oldini oladi)
        private var framePosted = false
        // VSYNC davri (EMA). FPS tolerance shunga nisbatan olinadi: 120 Hz da ~2 ms, 30 Hz panelda ~8 ms.
        private var prevCallbackNs = 0L
        private var vsyncNs = 0L

        private val applyRunnable = Runnable { applySettings() }
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            handler.removeCallbacks(applyRunnable)
            handler.post(applyRunnable)
        }
        private val envTick = object : Runnable {
            override fun run() {
                refreshEnvironment()
                handler.postDelayed(this, ENV_TICK_MS)
            }
        }
        private val frameCallback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                framePosted = false
                onFrame(frameTimeNanos)
            }
        }

        // ---------------- lifecycle ----------------

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            displayHz = DisplayInfo.maxRefreshHz(appContext)
            settingsRepo.registerListener(prefsListener)
            applySettings()
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            cancelFrame()
            settingsRepo.unregisterListener(prefsListener)
            sensor.stop()
            audio.stop()
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            scene.onSizeChanged(width.toFloat(), height.toFloat())
            updateSurfaceFrameRate()
            drawFrame()
            // Surface qayta yaratilganda (onSurfaceDestroyed -> onSurfaceChanged) ko'rinish o'zgarmasligi mumkin,
            // shuning uchun siklni shu yerda qayta tiklaymiz (aks holda animatsiya envTick'gacha ~10 s qotib qoladi).
            syncLoop()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            running = false
            cancelFrame()
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(envTick)
            if (visible) {
                handler.postDelayed(envTick, ENV_TICK_MS)
                // Uy ekrani ko'ringanda vidjetlarni yangilaymiz (WorkManager 15 daqiqadan tez ishlamaydi).
                WidgetRefresher.refreshIfStale(appContext)
            }
            refreshEnvironment()
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPixels: Int, yPixels: Int,
        ) {
            pageOffset = xOffset   // launcher sahifalari orasida fon biroz siljiydi
            // Animatsiya to'xtatilgan (o'yin rejimi / kam batareya) bo'lsa sikl yo'q: sahifa o'zgarganda bitta kadr chizamiz
            if (visible && !running) drawFrame()
        }

        // ---------------- teginish ----------------

        override fun onTouchEvent(event: MotionEvent) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> scene.addTouch(event.x, event.y)
                MotionEvent.ACTION_MOVE -> {
                    val now = System.currentTimeMillis()
                    if (now - lastMoveTouchMs > MOVE_TOUCH_INTERVAL_MS) {
                        lastMoveTouchMs = now
                        scene.addTouch(event.x, event.y)
                    }
                }
            }
            super.onTouchEvent(event)
        }

        /** Ko'p launcher'lar teginishni to'g'ridan-to'g'ri emas, "tap" komandasi sifatida yuboradi. */
        override fun onCommand(
            action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean,
        ): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP || action == WallpaperManager.COMMAND_SECONDARY_TAP) {
                scene.addTouch(x.toFloat(), y.toFloat())
            }
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        // ---------------- muhit va siyosat ----------------

        private fun applySettings() {
            scene.settings = settingsRepo.load()
            refreshEnvironment()
        }

        /** Sozlamalar, batareya, ob-havo va kun vaqtini qayta baholaydi (har ~10 s va o'zgarishda). */
        private fun refreshEnvironment() {
            val s = scene.settings
            scene.policy = policyEvaluator.evaluate(s, displayHz)
            val snapshot = if (s.dayNightEnabled) weatherRepo.cached() else null
            scene.weather = snapshot?.condition
            scene.palette = if (s.dayNightEnabled) {
                DayNightPalette.at(currentHour(), scene.weather, sunHoursOf(snapshot))
            } else {
                DayNightPalette.NIGHT
            }
            updateSurfaceFrameRate()
            syncSensors()
            syncLoop()
        }

        private fun syncSensors() {
            val p = scene.policy
            val s = scene.settings
            if (visible && p.animate && s.parallaxEnabled) sensor.start() else sensor.stop()
            // Audio faqat to'liq quvvat rejimida (Visualizer CPU/batareya sarflaydi)
            if (visible && p.animate && p.densityScale >= 1f && s.audioEnabled) audio.start() else audio.stop()
        }

        private fun syncLoop() {
            val shouldRun = visible && scene.policy.animate
            val surfaceOk = surfaceHolder.surface.isValid
            if (shouldRun && surfaceOk && !running) {
                running = true
                lastFrameNs = 0L
                prevCallbackNs = 0L
                postFrame()
            } else if ((!shouldRun || !surfaceOk) && running) {
                running = false
                cancelFrame()
            }
            if (visible && !scene.policy.animate) drawFrame()   // muzlatilgan: bitta statik kadr
        }

        private fun postFrame() {
            if (framePosted) return
            framePosted = true
            choreographer.postFrameCallback(frameCallback)
        }

        private fun cancelFrame() {
            choreographer.removeFrameCallback(frameCallback)
            framePosted = false
        }

        private fun updateSurfaceFrameRate() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && surfaceHolder.surface.isValid) {
                val fps = if (scene.policy.animate) scene.policy.targetFps.toFloat() else 0f
                surfaceHolder.surface.setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
            }
        }

        /** Saqlangan quyosh chiqishi/botishi (epoch ms) -> QURILMA mahalliy vaqtidagi soat (kun sanasi ahamiyatsiz). */
        private fun sunHoursOf(w: WeatherSnapshot?): SunHours? {
            val rise = w?.sunriseMs ?: return null
            val set = w.sunsetMs ?: return null
            return SunHours(hourOfDay(rise), hourOfDay(set))
        }

        private fun hourOfDay(epochMs: Long): Float {
            val c = Calendar.getInstance().apply { timeInMillis = epochMs }
            return c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f
        }

        private fun currentHour(): Float {
            val c = Calendar.getInstance()
            return c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f
        }

        // ---------------- render sikli ----------------

        private fun onFrame(frameTimeNanos: Long) {
            if (!running) return
            // VSYNC davrini o'lchaymiz (callback har VSYNC'da keladi, kadr o'tkazib yuborilganda ham)
            if (prevCallbackNs != 0L) {
                val d = frameTimeNanos - prevCallbackNs
                if (d in MIN_VSYNC_NS..MAX_VSYNC_NS) vsyncNs = if (vsyncNs == 0L) d else (vsyncNs * 7 + d) / 8
            }
            prevCallbackNs = frameTimeNanos

            val interval = 1_000_000_000L / scene.policy.targetFps.coerceAtLeast(1)
            if (lastFrameNs == 0L) lastFrameNs = frameTimeNanos
            val elapsed = frameTimeNanos - lastFrameNs
            // Tolerance = 1/4 VSYNC: jitter tufayli to'g'ri kadr o'tkazib yuborilmasin.
            // Eslatma: aniq pacing faqat ekran chastotasining bo'luvchilarida (120 -> 60/40/30). 90 FPS'ni
            // 120 Hz panelda faqat Surface.setFrameRate() panelni 90 Hz ga tushirsa olish mumkin.
            val tolerance = if (vsyncNs > 0) vsyncNs / 4 else DEFAULT_TOLERANCE_NS
            if (elapsed >= interval - tolerance) {
                val dt = (elapsed / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastFrameNs = frameTimeNanos
                // Float aniqligi: soatlab ishlagach sin() animatsiyasi "titraydi" — vaqtni 1 soatda o'rab turamiz
                timeSec = (timeSec + dt) % TIME_WRAP_SEC
                audio.update(timeSec, dt)
                scene.audioLevels = audio.levels
                scene.audioEnergy = audio.energy
                sensor.update(dt)
                scene.update(dt, timeSec)
                drawFrame()
            }
            postFrame()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            if (!holder.surface.isValid) return
            val canvas: Canvas = runCatching { holder.surface.lockHardwareCanvas() }.getOrNull() ?: return
            try {
                val s = scene.settings
                val strength = scene.width * 0.07f * s.parallaxStrength
                val offX = if (s.parallaxEnabled) -sensor.x * strength - (pageOffset - 0.5f) * scene.width * 0.1f else 0f
                val offY = if (s.parallaxEnabled) -sensor.y * strength else 0f
                if (photoRenderer.isEnabled()) photoRenderer.draw(canvas, scene.width, scene.height, 1f / scene.policy.targetFps.coerceAtLeast(15))
                else scene.draw(canvas, offX, offY)
            } finally {
                // Surface draw paytida yo'q bo'lib qolsa unlock IllegalStateException berishi mumkin
                runCatching { holder.surface.unlockCanvasAndPost(canvas) }
            }
        }
    }

    private companion object {
        const val ENV_TICK_MS = 10_000L
        const val DEFAULT_TOLERANCE_NS = 2_000_000L
        const val MIN_VSYNC_NS = 3_000_000L      // ~333 Hz
        const val MAX_VSYNC_NS = 50_000_000L     // 20 Hz
        const val TIME_WRAP_SEC = 3600f
        const val MOVE_TOUCH_INTERVAL_MS = 120L
    }
}
